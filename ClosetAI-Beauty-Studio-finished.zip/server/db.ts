import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, beautyProfiles, outfitRecommendations, routineProgress, sharedItems, skinAnalyses, skincareRoutines, users, wardrobeItems } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); } catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) { if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; } }
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; } else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1); return result[0]; }

export async function getProfile(userId: number) { const db = await getDb(); if (!db) return undefined; const result = await db.select().from(beautyProfiles).where(eq(beautyProfiles.userId, userId)).limit(1); return result[0]; }
export async function saveProfile(userId: number, data: { skinType: string; concernsJson: string; allergiesJson: string; preferencesJson: string }) { const db = await getDb(); if (!db) return undefined; const existing = await getProfile(userId); if (existing) { await db.update(beautyProfiles).set(data).where(eq(beautyProfiles.userId, userId)); return getProfile(userId); } await db.insert(beautyProfiles).values({ userId, ...data }); return getProfile(userId); }
export async function listWardrobe(userId: number) { const db = await getDb(); if (!db) return []; return db.select().from(wardrobeItems).where(eq(wardrobeItems.userId, userId)).orderBy(desc(wardrobeItems.createdAt)); }
export async function addWardrobeItem(item: typeof wardrobeItems.$inferInsert) { const db = await getDb(); if (!db) return undefined; const result = await db.insert(wardrobeItems).values(item); const id = Number(result[0].insertId); const rows = await db.select().from(wardrobeItems).where(and(eq(wardrobeItems.userId, item.userId), eq(wardrobeItems.id, id))).limit(1); return rows[0]; }
export async function addSkinAnalysis(item: typeof skinAnalyses.$inferInsert) { const db = await getDb(); if (!db) return undefined; const result = await db.insert(skinAnalyses).values(item); const id = Number(result[0].insertId); const rows = await db.select().from(skinAnalyses).where(and(eq(skinAnalyses.userId, item.userId), eq(skinAnalyses.id, id))).limit(1); return rows[0]; }
export async function listSkinAnalyses(userId: number) { const db = await getDb(); if (!db) return []; return db.select().from(skinAnalyses).where(eq(skinAnalyses.userId, userId)).orderBy(desc(skinAnalyses.createdAt)); }
export async function addOutfitRecommendation(item: typeof outfitRecommendations.$inferInsert) { const db = await getDb(); if (!db) return undefined; const result = await db.insert(outfitRecommendations).values(item); const id = Number(result[0].insertId); const rows = await db.select().from(outfitRecommendations).where(and(eq(outfitRecommendations.userId, item.userId), eq(outfitRecommendations.id, id))).limit(1); return rows[0]; }
export async function listOutfitRecommendations(userId: number) { const db = await getDb(); if (!db) return []; return db.select().from(outfitRecommendations).where(eq(outfitRecommendations.userId, userId)).orderBy(desc(outfitRecommendations.createdAt)); }
export async function saveRoutine(userId: number, data: { morningJson: string; eveningJson: string; note: string }) { const db = await getDb(); if (!db) return undefined; const existing = await db.select().from(skincareRoutines).where(eq(skincareRoutines.userId, userId)).limit(1); if (existing[0]) { await db.update(skincareRoutines).set(data).where(eq(skincareRoutines.userId, userId)); return (await db.select().from(skincareRoutines).where(eq(skincareRoutines.userId, userId)).limit(1))[0]; } await db.insert(skincareRoutines).values({ userId, ...data }); return (await db.select().from(skincareRoutines).where(eq(skincareRoutines.userId, userId)).limit(1))[0]; }
export async function getRoutine(userId: number) { const db = await getDb(); if (!db) return undefined; return (await db.select().from(skincareRoutines).where(eq(skincareRoutines.userId, userId)).limit(1))[0]; }
export async function listRoutines(userId: number) { const db = await getDb(); if (!db) return []; return db.select().from(skincareRoutines).where(eq(skincareRoutines.userId, userId)).orderBy(desc(skincareRoutines.updatedAt)); }
export async function updateOutfitRecommendation(userId: number, id: number, resultJson: string) { const db = await getDb(); if (!db) return undefined; await db.update(outfitRecommendations).set({ resultJson }).where(and(eq(outfitRecommendations.userId, userId), eq(outfitRecommendations.id, id))); return (await db.select().from(outfitRecommendations).where(and(eq(outfitRecommendations.userId, userId), eq(outfitRecommendations.id, id))).limit(1))[0]; }

export async function getTodayProgress(userId: number, dayKey: string) { const db = await getDb(); if (!db) return undefined; return (await db.select().from(routineProgress).where(and(eq(routineProgress.userId, userId), eq(routineProgress.dayKey, dayKey))).limit(1))[0]; }
export async function saveTodayProgress(userId: number, data: { dayKey: string; routineId?: number; morningDone: number; eveningDone: number }) { const db = await getDb(); if (!db) return undefined; const existing = await getTodayProgress(userId, data.dayKey); if (existing) { await db.update(routineProgress).set(data).where(and(eq(routineProgress.userId, userId), eq(routineProgress.dayKey, data.dayKey))); return getTodayProgress(userId, data.dayKey); } await db.insert(routineProgress).values({ userId, ...data }); return getTodayProgress(userId, data.dayKey); }
export async function listProgress(userId: number) { const db = await getDb(); if (!db) return []; return db.select().from(routineProgress).where(eq(routineProgress.userId, userId)).orderBy(desc(routineProgress.dayKey)); }
export function calculateConsecutiveStreak(entries: Array<{ dayKey: string; morningDone: number; eveningDone: number }>, today = new Date().toISOString().slice(0, 10)) { const completed = new Set(entries.filter((entry) => entry.morningDone || entry.eveningDone).map((entry) => entry.dayKey)); let streak = 0; const cursor = new Date(`${today}T12:00:00Z`); while (completed.has(cursor.toISOString().slice(0, 10))) { streak += 1; cursor.setUTCDate(cursor.getUTCDate() - 1); } return streak; }
export async function createShare(userId: number, data: { shareToken: string; kind: "routine" | "outfit"; payloadJson: string }) { const db = await getDb(); if (!db) return undefined; await db.insert(sharedItems).values({ userId, ...data }); return (await db.select().from(sharedItems).where(eq(sharedItems.shareToken, data.shareToken)).limit(1))[0]; }
export async function getShare(shareToken: string) { const db = await getDb(); if (!db) return undefined; return (await db.select().from(sharedItems).where(eq(sharedItems.shareToken, shareToken)).limit(1))[0]; }
