import { describe, expect, it } from "vitest";
import { getGuestListFallback, getGuestProgress } from "../client/src/lib/guestFallbacks";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createGuestContext(): TrpcContext {
  return {
    user: undefined,
    req: {} as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("anonymous guest behavior", () => {
  it("uses local wardrobe and skin-history demo data when protected queries have no data", () => {
    const demoWardrobe = [{ name: "Demo knit", type: "Layer" }];
    const demoHistory = [{ wellnessScore: 76 }];

    const unauthorized = { data: { code: "UNAUTHORIZED" } };
    expect(getGuestListFallback(undefined, demoWardrobe, unauthorized)).toEqual(demoWardrobe);
    expect(getGuestListFallback([], demoHistory, unauthorized)).toEqual(demoHistory);
    expect(getGuestProgress(undefined, unauthorized)).toEqual({ morningDone: false, eveningDone: false, streak: 0 });
  });

  it("keeps persistence protected for anonymous callers", async () => {
    const caller = appRouter.createCaller(createGuestContext());

    await expect(caller.progress.today()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.wardrobe.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
