import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { calculateConsecutiveStreak } from "./db";

describe("routine tracker and sharing contracts", () => {
  it("exposes progress and share procedures", () => {
    expect(Object.keys(appRouter._def.procedures)).toEqual(expect.arrayContaining([
      "progress.today",
      "progress.history",
      "progress.save",
      "shares.create",
      "shares.get",
    ]));
  });

  it("calculates only consecutive completed days", () => {
    expect(calculateConsecutiveStreak([
      { dayKey: "2026-08-17", morningDone: 1, eveningDone: 0 },
      { dayKey: "2026-08-16", morningDone: 1, eveningDone: 1 },
      { dayKey: "2026-08-14", morningDone: 1, eveningDone: 1 },
    ], "2026-08-17")).toBe(2);
  });

  it("keeps share kinds constrained to routine and outfit", () => {
    expect(appRouter._def.procedures["shares.create"]).toBeDefined();
    expect(appRouter._def.procedures["shares.get"]).toBeDefined();
  });
});
