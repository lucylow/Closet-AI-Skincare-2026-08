import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";

const requiredSections = ["Wardrobe", "Outfits", "Skin Analysis", "My Skin Routine", "Skin Tone Studio", "Trends"];

describe("ClosetAI Beauty Studio contracts", () => {
  it("exposes the requested AI procedures", () => {
    const procedures = appRouter._def.procedures;
    expect(procedures).toHaveProperty("ai.analyzeSkin");
    expect(procedures).toHaveProperty("ai.generateOutfit");
    expect(procedures).toHaveProperty("ai.generateRoutine");
    expect(procedures).toHaveProperty("ai.analyzeTone");
  });

  it("keeps the exact navigation labels as a stable product contract", () => {
    expect(requiredSections).toEqual([
      "Wardrobe",
      "Outfits",
      "Skin Analysis",
      "My Skin Routine",
      "Skin Tone Studio",
      "Trends",
    ]);
  });
});
