import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("public application access", () => {
  it("keeps the main app routes public", () => {
    const appSource = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");
    expect(appSource).toContain('<Route path="/" component={Home} />');
    expect(appSource).toContain('<Route path="/skin-analysis" component={Home} />');
    expect(appSource).not.toContain("Sign in to continue");
  });

  it("does not block the reusable dashboard shell for guests", () => {
    const layoutSource = readFileSync(resolve(process.cwd(), "client/src/components/DashboardLayout.tsx"), "utf8");
    expect(layoutSource).not.toContain("Access to this dashboard requires authentication");
    expect(layoutSource).not.toContain("startLogin()");
  });

  it("keeps demo content available when protected queries fail for guests", () => {
    const homeSource = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
    expect(homeSource).toContain("guestDemoFallback");
    expect(homeSource).toContain("getGuestListFallback(skinHistory.data, demoHistory, skinHistory.error)");
    expect(homeSource).toContain("getGuestListFallback(wardrobeQuery.data?.length");
    expect(homeSource).toContain("No sign-in required");
  });
});
