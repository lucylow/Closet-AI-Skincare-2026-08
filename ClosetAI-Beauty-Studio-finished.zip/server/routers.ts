import { z } from "zod";
import { nanoid } from "nanoid";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { invokeLLM } from "./_core/llm";
import { addOutfitRecommendation, addSkinAnalysis, addWardrobeItem, calculateConsecutiveStreak, createShare, getProfile, getRoutine, getShare, getTodayProgress, listOutfitRecommendations, listProgress, listRoutines, listSkinAnalyses, listWardrobe, saveProfile, saveRoutine, saveTodayProgress, updateOutfitRecommendation } from "./db";
import { storagePut } from "./storage";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

export const skinAnalysisSchema = {
  type: "object",
  properties: {
    summary: { type: "string" },
    wellnessScore: { type: "integer", minimum: 0, maximum: 100 },
    hydration: { type: "integer", minimum: 0, maximum: 100 },
    texture: { type: "integer", minimum: 0, maximum: 100 },
    tone: { type: "integer", minimum: 0, maximum: 100 },
    pores: { type: "integer", minimum: 0, maximum: 100 },
    wrinkles: { type: "integer", minimum: 0, maximum: 100 },
    skinType: { type: "string" },
    undertone: { type: "string" },
    nextStep: { type: "string" },
    confidence: { type: "string" },
    safetyNote: { type: "string" },
    overlays: { type: "array", items: { type: "object", properties: { label: { type: "string" }, x: { type: "number", minimum: 0, maximum: 100 }, y: { type: "number", minimum: 0, maximum: 100 }, color: { type: "string" }, confidence: { type: "number", minimum: 0, maximum: 1 } }, required: ["label", "x", "y", "color", "confidence"], additionalProperties: false } },
  },
  required: ["summary", "wellnessScore", "hydration", "texture", "tone", "pores", "wrinkles", "skinType", "undertone", "nextStep", "confidence", "safetyNote", "overlays"],
  additionalProperties: false,
} as const;

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  profile: router({
    get: protectedProcedure.query(({ ctx }) => getProfile(ctx.user.id)),
    save: protectedProcedure.input(z.object({ skinType: z.string(), concerns: z.array(z.string()), allergies: z.array(z.string()), preferences: z.record(z.string(), z.string()) })).mutation(({ ctx, input }) => saveProfile(ctx.user.id, { skinType: input.skinType, concernsJson: JSON.stringify(input.concerns), allergiesJson: JSON.stringify(input.allergies), preferencesJson: JSON.stringify(input.preferences) })),
  }),
  wardrobe: router({
    list: protectedProcedure.query(({ ctx }) => listWardrobe(ctx.user.id)),
    create: protectedProcedure.input(z.object({ imageKey: z.string().min(1), imageUrl: z.string().min(1), name: z.string().min(1), category: z.string().min(1), color: z.string().min(1), tags: z.array(z.string()) })).mutation(({ ctx, input }) => addWardrobeItem({ userId: ctx.user.id, ...input, tagsJson: JSON.stringify(input.tags) })),
    upload: protectedProcedure.input(z.object({ dataUrl: z.string().min(30).max(8_000_000), fileName: z.string().min(1), contentType: z.string().regex(/^image\/(png|jpeg|webp)$/), name: z.string().min(1), category: z.string().min(1), color: z.string().min(1), tags: z.array(z.string()) })).mutation(async ({ ctx, input }) => { const encoded = input.dataUrl.split(",")[1]; if (!encoded) throw new Error("Invalid image data."); const stored = await storagePut(`${ctx.user.id}/wardrobe/${input.fileName}`, Buffer.from(encoded, "base64"), input.contentType); return addWardrobeItem({ userId: ctx.user.id, imageKey: stored.key, imageUrl: stored.url, name: input.name, category: input.category, color: input.color, tagsJson: JSON.stringify(input.tags) }); }),
  }),
  skinHistory: router({
    list: protectedProcedure.query(({ ctx }) => listSkinAnalyses(ctx.user.id)),
  }),
  outfits: router({
    history: protectedProcedure.query(({ ctx }) => listOutfitRecommendations(ctx.user.id)),
    update: protectedProcedure.input(z.object({ id: z.number().int(), result: z.record(z.string(), z.unknown()) })).mutation(({ ctx, input }) => updateOutfitRecommendation(ctx.user.id, input.id, JSON.stringify(input.result))),
  }),
  routine: router({
    get: protectedProcedure.query(({ ctx }) => getRoutine(ctx.user.id)),
    history: protectedProcedure.query(({ ctx }) => listRoutines(ctx.user.id)),
    save: protectedProcedure.input(z.object({ morning: z.array(z.unknown()), evening: z.array(z.unknown()), note: z.string() })).mutation(({ ctx, input }) => saveRoutine(ctx.user.id, { morningJson: JSON.stringify(input.morning), eveningJson: JSON.stringify(input.evening), note: input.note })),
  }),
  progress: router({
    today: protectedProcedure.query(async ({ ctx }) => { const today = new Date().toISOString().slice(0, 10); const [progress, history] = await Promise.all([getTodayProgress(ctx.user.id, today), listProgress(ctx.user.id)]); return { ...progress, streak: calculateConsecutiveStreak(history, today) }; }),
    history: protectedProcedure.query(({ ctx }) => listProgress(ctx.user.id)),
    save: protectedProcedure.input(z.object({ dayKey: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), routineId: z.number().int().optional(), morningDone: z.boolean(), eveningDone: z.boolean() })).mutation(({ ctx, input }) => saveTodayProgress(ctx.user.id, { dayKey: input.dayKey, routineId: input.routineId, morningDone: input.morningDone ? 1 : 0, eveningDone: input.eveningDone ? 1 : 0 })),
  }),
  shares: router({
    create: protectedProcedure.input(z.object({ kind: z.enum(["routine", "outfit"]), payload: z.record(z.string(), z.unknown()) })).mutation(({ ctx, input }) => createShare(ctx.user.id, { shareToken: nanoid(18), kind: input.kind, payloadJson: JSON.stringify(input.payload) })),
    get: publicProcedure.input(z.object({ token: z.string().min(8).max(48) })).query(({ input }) => getShare(input.token)),
  }),
  ai: router({
    analyzeSkin: protectedProcedure
      .input(z.object({
        imageUrl: z.string().min(20).max(8_000_000),
        profile: z.object({
          skinType: z.string().optional(),
          concerns: z.array(z.string()).default([]),
          allergies: z.array(z.string()).default([]),
        }).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const response = await invokeLLM({
          model: "gemini-3-flash-preview",
          messages: [
            {
              role: "system",
              content: "You are a careful skincare wellness assistant. Analyze only visible, non-diagnostic patterns in the supplied face photo. Never diagnose a disease, infer race or identity, or recommend prescription treatment. If image quality is insufficient, say so in confidence and give a safer next step. Return JSON only.",
            },
            {
              role: "user",
              content: [
                { type: "text", text: `Create a concise wellness snapshot covering hydration, texture, tone, pores, wrinkles, skin type, undertone, a gentle next step, confidence, a safety note, and a small array of visible concern overlays. For each overlay, use normalized x/y percentages on the displayed image, a short label, a hex color, and confidence. Only include concerns actually visible in this image; if none are clear, return an empty array. User profile context: ${JSON.stringify(input.profile ?? {})}` },
                { type: "image_url", image_url: { url: input.imageUrl, detail: "auto" } },
              ],
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: { name: "skin_analysis", strict: true, schema: skinAnalysisSchema },
          },
        });
        const content = response.choices[0]?.message?.content;
        if (typeof content !== "string") throw new Error("The AI returned no structured skin analysis.");
        const parsed = JSON.parse(content);
        const encoded = input.imageUrl.split(",")[1];
        const mimeMatch = input.imageUrl.match(/^data:(image\/(?:png|jpeg|webp));base64,/);
        const stored = encoded && mimeMatch ? await storagePut(`${ctx.user.id}/skin-analysis/face`, Buffer.from(encoded, "base64"), mimeMatch[1]) : undefined;
        const saved = await addSkinAnalysis({ userId: ctx.user.id, imageKey: stored?.key ?? null, imageUrl: stored?.url ?? null, engine: "Manus vision AI", wellnessScore: parsed.wellnessScore, hydration: parsed.hydration, texture: parsed.texture, tone: parsed.tone, pores: parsed.pores, wrinkles: parsed.wrinkles, resultJson: JSON.stringify(parsed) });
        return { ...parsed, createdAt: Date.now(), engine: "Manus vision AI", persistedId: saved?.id ?? null };
      }),
    generateOutfit: protectedProcedure
      .input(z.object({ occasion: z.string().min(2), weather: z.string().min(2), wardrobe: z.array(z.object({ id: z.string(), name: z.string(), type: z.string(), color: z.string() })).min(1) }))
      .mutation(async ({ ctx, input }) => {
        const response = await invokeLLM({
          model: "gpt-5-mini",
          messages: [
            { role: "system", content: "You are a personal stylist. Use only the supplied wardrobe items. Return JSON only and explain the reasoning in friendly, concise language." },
            { role: "user", content: JSON.stringify(input) },
          ],
          response_format: { type: "json_schema", json_schema: { name: "outfit_plan", strict: true, schema: { type: "object", properties: { title: { type: "string" }, itemIds: { type: "array", items: { type: "string" } }, rationale: { type: "string" }, alternate: { type: "string" } }, required: ["title", "itemIds", "rationale", "alternate"], additionalProperties: false } } },
        });
        const content = response.choices[0]?.message?.content;
        if (typeof content !== "string") throw new Error("The AI returned no outfit plan.");
        const parsed = JSON.parse(content);
        const saved = await addOutfitRecommendation({ userId: ctx.user.id, occasion: input.occasion, weather: input.weather, resultJson: JSON.stringify(parsed) });
        return { ...parsed, persistedId: saved?.id ?? null };
      }),
    generateRoutine: protectedProcedure
      .input(z.object({ profile: z.object({ skinType: z.string(), concerns: z.array(z.string()), allergies: z.array(z.string()) }), analysis: z.object({ hydration: z.number(), texture: z.number(), tone: z.number(), pores: z.number(), wrinkles: z.number() }) }))
      .mutation(async ({ ctx, input }) => {
        const response = await invokeLLM({
          model: "gpt-5-mini",
          messages: [
            { role: "system", content: "You are a cautious skincare wellness assistant. Create a simple non-medical morning and evening routine. Respect allergies. Return JSON only. Do not diagnose or recommend prescription treatment." },
            { role: "user", content: JSON.stringify(input) },
          ],
          response_format: { type: "json_schema", json_schema: { name: "routine_plan", strict: true, schema: { type: "object", properties: { morning: { type: "array", items: { type: "object", properties: { step: { type: "string" }, purpose: { type: "string" }, ingredientFamilies: { type: "array", items: { type: "string" } } }, required: ["step", "purpose", "ingredientFamilies"], additionalProperties: false } }, evening: { type: "array", items: { type: "object", properties: { step: { type: "string" }, purpose: { type: "string" }, ingredientFamilies: { type: "array", items: { type: "string" } } }, required: ["step", "purpose", "ingredientFamilies"], additionalProperties: false } }, note: { type: "string" } }, required: ["morning", "evening", "note"], additionalProperties: false } } },
        });
        const content = response.choices[0]?.message?.content;
        if (typeof content !== "string") throw new Error("The AI returned no routine plan.");
        const parsed = JSON.parse(content);
        const saved = await saveRoutine(ctx.user.id, { morningJson: JSON.stringify(parsed.morning), eveningJson: JSON.stringify(parsed.evening), note: parsed.note });
        return { ...parsed, persistedId: saved?.id ?? null };
      }),
    analyzeTone: protectedProcedure
      .input(z.object({ imageUrl: z.string().min(20).max(8_000_000) }))
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          model: "gemini-3-flash-preview",
          messages: [
            { role: "system", content: "Analyze visible facial color only. Never infer race, ethnicity, identity, or health. Return JSON only with a tentative undertone and inclusive clothing palette." },
            { role: "user", content: [{ type: "text", text: "Return a warm/cool/neutral/mixed undertone, confidence, five clothing color names with hex values, and a short rationale." }, { type: "image_url", image_url: { url: input.imageUrl, detail: "auto" } }] },
          ],
          response_format: { type: "json_schema", json_schema: { name: "tone_palette", strict: true, schema: { type: "object", properties: { undertone: { type: "string" }, confidence: { type: "string" }, rationale: { type: "string" }, colors: { type: "array", items: { type: "object", properties: { name: { type: "string" }, hex: { type: "string" } }, required: ["name", "hex"], additionalProperties: false } } }, required: ["undertone", "confidence", "rationale", "colors"], additionalProperties: false } } },
        });
        const content = response.choices[0]?.message?.content;
        if (typeof content !== "string") throw new Error("The AI returned no tone palette.");
        return JSON.parse(content);
      }),
  }),
});

export type AppRouter = typeof appRouter;
