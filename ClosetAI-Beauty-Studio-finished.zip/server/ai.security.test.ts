import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function anonymousContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("protected ClosetAI procedures", () => {
  it("rejects profile, wardrobe, and history access without a Manus session", async () => {
    const caller = appRouter.createCaller(anonymousContext());
    await expect(caller.profile.get()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.wardrobe.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.skinHistory.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("keeps the required structured skin dimensions in the router contract", () => {
    const procedures = appRouter._def.procedures;
    expect(Object.keys(procedures)).toEqual(expect.arrayContaining(["ai.analyzeSkin", "ai.generateOutfit", "ai.generateRoutine", "ai.analyzeTone", "profile.get", "wardrobe.upload", "skinHistory.list", "routine.history", "outfits.update"]));
  });
});
