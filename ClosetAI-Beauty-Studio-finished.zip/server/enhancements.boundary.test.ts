import { beforeEach, describe, expect, it, vi } from "vitest";

const progress = new Map<string, { dayKey: string; morningDone: number; eveningDone: number }>();
const shares = new Map<string, { shareToken: string; kind: "routine" | "outfit"; payloadJson: string }>();

vi.mock("./db", async () => {
  const actual = await vi.importActual<typeof import("./db")>("./db");
  return {
    ...actual,
    getTodayProgress: vi.fn(async (_userId: number, dayKey: string) => progress.get(dayKey)),
    listProgress: vi.fn(async () => Array.from(progress.values())),
    saveTodayProgress: vi.fn(async (_userId: number, input: { dayKey: string; routineId?: number; morningDone: number; eveningDone: number }) => { progress.set(input.dayKey, input); return input; }),
    createShare: vi.fn(async (_userId: number, input: { shareToken: string; kind: "routine" | "outfit"; payloadJson: string }) => { const saved = { ...input }; shares.set(input.shareToken, saved); return saved; }),
    getShare: vi.fn(async (token: string) => shares.get(token)),
  };
});

const { appRouter, skinAnalysisSchema } = await import("./routers");

describe("enhancement router boundaries", () => {
  beforeEach(() => { progress.clear(); shares.clear(); });

  it("saves routine progress and lists it through protected procedures", async () => {
    const ctx = { user: { id: 7 }, req: {}, res: {} } as never;
    const caller = appRouter.createCaller(ctx);
    await caller.progress.save({ dayKey: "2026-08-17", morningDone: true, eveningDone: false });
    const today = await caller.progress.today();
    const history = await caller.progress.history();
    expect(today.morningDone).toBe(1);
    expect(today.streak).toBe(1);
    expect(history).toHaveLength(1);
  });

  it("creates and retrieves a share payload through public retrieval", async () => {
    const ctx = { user: { id: 7 }, req: {}, res: {} } as never;
    const caller = appRouter.createCaller(ctx);
    const created = await caller.shares.create({ kind: "routine", payload: { morning: ["Cleanse"], evening: ["Treat"] } });
    const retrieved = await appRouter.createCaller({ user: null, req: {}, res: {} } as never).shares.get({ token: created!.shareToken });
    expect(retrieved?.kind).toBe("routine");
    expect(JSON.parse(retrieved!.payloadJson)).toEqual({ morning: ["Cleanse"], evening: ["Treat"] });
  });

  it("requires bounded normalized overlay fields", () => {
    const overlay = (skinAnalysisSchema.properties as any).overlays;
    expect(overlay.type).toBe("array");
    expect(overlay.items.required).toEqual(expect.arrayContaining(["label", "x", "y", "color", "confidence"]));
    expect(overlay.items.properties.x.minimum).toBe(0);
    expect(overlay.items.properties.x.maximum).toBe(100);
    expect(overlay.items.properties.y.minimum).toBe(0);
    expect(overlay.items.properties.y.maximum).toBe(100);
  });
});
