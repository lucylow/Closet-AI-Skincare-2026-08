CREATE TABLE `beauty_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`skinType` varchar(64) NOT NULL DEFAULT 'combination',
	`concernsJson` text NOT NULL,
	`allergiesJson` text NOT NULL,
	`preferencesJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `beauty_profiles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `skin_analyses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`imageKey` varchar(512),
	`imageUrl` varchar(1024),
	`engine` varchar(80) NOT NULL,
	`wellnessScore` int NOT NULL,
	`hydration` int NOT NULL,
	`texture` int NOT NULL,
	`tone` int NOT NULL,
	`pores` int NOT NULL,
	`wrinkles` int NOT NULL,
	`resultJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `skin_analyses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wardrobe_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`imageKey` varchar(512) NOT NULL,
	`imageUrl` varchar(1024) NOT NULL,
	`name` varchar(160) NOT NULL,
	`category` varchar(80) NOT NULL,
	`color` varchar(80) NOT NULL,
	`tagsJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `wardrobe_items_id` PRIMARY KEY(`id`)
);
