CREATE TABLE `routine_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`routineId` int,
	`dayKey` varchar(16) NOT NULL,
	`morningDone` int NOT NULL DEFAULT 0,
	`eveningDone` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `routine_progress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `shared_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`shareToken` varchar(48) NOT NULL,
	`kind` enum('routine','outfit') NOT NULL,
	`payloadJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `shared_items_id` PRIMARY KEY(`id`),
	CONSTRAINT `shared_items_shareToken_unique` UNIQUE(`shareToken`)
);
