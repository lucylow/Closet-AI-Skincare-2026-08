import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const beautyProfiles = mysqlTable("beauty_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  skinType: varchar("skinType", { length: 64 }).default("combination").notNull(),
  concernsJson: text("concernsJson").notNull(),
  allergiesJson: text("allergiesJson").notNull(),
  preferencesJson: text("preferencesJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const wardrobeItems = mysqlTable("wardrobe_items", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  imageKey: varchar("imageKey", { length: 512 }).notNull(),
  imageUrl: varchar("imageUrl", { length: 1024 }).notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  category: varchar("category", { length: 80 }).notNull(),
  color: varchar("color", { length: 80 }).notNull(),
  tagsJson: text("tagsJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const outfitRecommendations = mysqlTable("outfit_recommendations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  occasion: varchar("occasion", { length: 120 }).notNull(),
  weather: varchar("weather", { length: 160 }).notNull(),
  resultJson: text("resultJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const skincareRoutines = mysqlTable("skincare_routines", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  morningJson: text("morningJson").notNull(),
  eveningJson: text("eveningJson").notNull(),
  note: text("note").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const routineProgress = mysqlTable("routine_progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  routineId: int("routineId"),
  dayKey: varchar("dayKey", { length: 16 }).notNull(),
  morningDone: int("morningDone").default(0).notNull(),
  eveningDone: int("eveningDone").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const sharedItems = mysqlTable("shared_items", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  shareToken: varchar("shareToken", { length: 48 }).notNull().unique(),
  kind: mysqlEnum("kind", ["routine", "outfit"]).notNull(),
  payloadJson: text("payloadJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const skinAnalyses = mysqlTable("skin_analyses", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  imageKey: varchar("imageKey", { length: 512 }),
  imageUrl: varchar("imageUrl", { length: 1024 }),
  engine: varchar("engine", { length: 80 }).notNull(),
  wellnessScore: int("wellnessScore").notNull(),
  hydration: int("hydration").notNull(),
  texture: int("texture").notNull(),
  tone: int("tone").notNull(),
  pores: int("pores").notNull(),
  wrinkles: int("wrinkles").notNull(),
  resultJson: text("resultJson").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type BeautyProfile = typeof beautyProfiles.$inferSelect;
export type WardrobeItem = typeof wardrobeItems.$inferSelect;
export type SkinAnalysis = typeof skinAnalyses.$inferSelect;
export type RoutineProgress = typeof routineProgress.$inferSelect;
export type SharedItem = typeof sharedItems.$inferSelect;
export type OutfitRecommendation = typeof outfitRecommendations.$inferSelect;
export type SkincareRoutine = typeof skincareRoutines.$inferSelect;
