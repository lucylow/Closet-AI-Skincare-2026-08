# ClosetAI Beauty Studio
## 20-Page Product, Architecture, and Implementation Plan

**Author:** Manus AI  
**Prepared:** August 17, 2026  
**Project:** Permanent Manus application based on the supplied ClosetAI/Replit source archive

---

# Page 1 — Executive Summary

ClosetAI Beauty Studio will be a unified personal style and skincare workspace. It will combine a digital wardrobe, AI outfit planning, YouCam-inspired virtual try-on, vision-based skin analysis, personalized routines, tone-aware color styling, product discovery, longitudinal progress tracking, and a beauty-and-wellness profile. The product will feel like one coherent personal assistant rather than a collection of disconnected demos.

The application will be rebuilt as a permanent Manus full-stack web application. The supplied source archive is a valuable feature reference: it already contains wardrobe, try-on, skin-analysis, tone, trends, and sponsor-oriented components. The Manus implementation will retain those product concepts while replacing Replit-specific assumptions with Manus authentication, database procedures, server-side AI calls, and managed storage.

The first implementation release will provide a complete, responsive application experience with production-shaped flows. Where a paid third-party YouCam/Perfect Corp credential is not available, the interface will use a clearly labeled integration-ready adapter and the Manus vision LLM for structured analysis. No medical diagnosis will be claimed. Skin results will be framed as wellness observations, confidence-aware recommendations, and prompts to consult a qualified professional when appropriate.

**Primary success measure:** a user can sign in, create a beauty profile, add wardrobe items, request an outfit, upload a face image, receive a structured skin report, generate a morning/evening routine, explore matched products, inspect tone-aligned palettes, and revisit progress from one sidebar-driven dashboard.

---

# Page 2 — Product Vision and User Promise

The product promise is: **“Your wardrobe, your skin, and your everyday confidence in one intelligent studio.”** ClosetAI should reduce the friction between getting dressed and taking care of oneself. A skin tone result should influence clothing palette suggestions. Weather and occasion should influence outfit recommendations. Skin concerns and preferences should shape the routine builder. The profile should connect all of these contexts without forcing the user to repeat themselves.

The experience is designed for style-conscious users who want practical, personalized guidance but do not want a complex clinical workflow. The user should feel supported, not judged. The system must avoid language that implies certainty about a medical condition, avoid exaggerated beauty claims, and explain why a recommendation was made.

The product will have three layers. The **workspace layer** contains navigation, profile context, saved items, and history. The **intelligence layer** contains vision analysis, LLM reasoning, tagging, ranking, and structured recommendation generation. The **trust layer** contains consent, data controls, explanations, uncertainty indicators, safety copy, and deletion controls.

The supplied reference materials describe a multi-agent wardrobe concept involving garment vision, stylist, weather/context, gap analysis, and sustainability. This plan keeps that vocabulary as an internal conceptual model while implementing the first release through typed server procedures and a dependable orchestration boundary.

---

# Page 3 — Scope, Personas, and Core Journeys

The primary persona is a user with a growing wardrobe and a desire for low-effort daily styling. A secondary persona is a skincare learner who wants to understand visible skin patterns and organize a routine. A third persona is a beauty-and-fashion enthusiast who wants to experiment with virtual looks and color palettes before deciding what to wear or buy.

The first core journey is **“start my day.”** The user opens the dashboard, sees the weather and occasion prompt, reviews a generated outfit, and optionally opens virtual try-on. The second is **“understand my skin.”** The user uploads a well-lit front-facing image, reviews concern scores and guidance, then saves a routine. The third is **“shop with context.”** The user opens product discovery, sees items matched to their concerns and allergies, and understands the relevant ingredients before leaving the application.

| Journey | Entry point | Intelligence | Saved outcome |
|---|---|---|---|
| Add clothing | Wardrobe | Garment vision/tagging | Wardrobe item |
| Plan outfit | Outfits | LLM + weather + wardrobe | Outfit plan |
| Try a look | Virtual Try-On Studio | Image/overlay adapter | Try-on session |
| Analyze skin | Skin Analysis | Vision LLM / YouCam adapter | Analysis record |
| Build routine | My Skin Routine | LLM + profile + analysis | AM/PM routine |
| Match colors | Skin Tone Studio | Tone/undertone analysis | Palette profile |
| Discover products | My Skin Routine | Concern/ingredient ranking | Saved products |
| Track change | Dashboard/history | Trend calculations | Progress chart |

The application will treat every journey as resumable. Empty states should tell users what to do next. Loading states should explain the operation. Errors should offer a recovery action rather than silently failing.

---

# Page 4 — Information Architecture and Sidebar Contract

The persistent sidebar is the structural anchor of the application. The exact requested labels must appear unchanged: **Wardrobe, Outfits, Skin Analysis, My Skin Routine, Skin Tone Studio, and Trends.** A dashboard home may be labeled “Overview” or “Dashboard,” but it must not replace the required section names.

The sidebar will also include the ClosetAI Beauty Studio wordmark, a compact profile summary, a “Scan skin” primary action, and a lower utility area for settings, data controls, and sign out. On small screens the sidebar becomes a sheet or bottom navigation pattern while retaining the same labels and route semantics.

| Label | Route | Purpose |
|---|---|---|
| Wardrobe | `/wardrobe` | Upload, tag, filter, and browse garments |
| Outfits | `/outfits` | Daily outfit recommendations and saved looks |
| Skin Analysis | `/skin-analysis` | Upload face photo and review results |
| My Skin Routine | `/my-skin-routine` | AM/PM routine and product discovery |
| Skin Tone Studio | `/skin-tone-studio` | Tone detection and clothing palette matching |
| Trends | `/trends` | Seasonal style and beauty inspiration |

Route transitions should preserve the shell and active navigation state. Each page must include a clear title, one primary action, supporting context, and an escape route. The shell will use the scaffold’s dashboard layout component where suitable, but the final visual treatment will be customized for the beauty-and-wellness domain.

---

# Page 5 — Visual Direction and Design System

The proposed direction is **editorial soft-luxury wellness**. It combines warm ivory surfaces, muted rose and clay accents, deep espresso text, soft sage for wellness states, and ink-blue for informational emphasis. The style should feel premium but approachable: generous whitespace, quiet borders, rounded cards, subtle texture, and strong typographic hierarchy.

Typography will pair a refined display serif for page-level moments with a highly legible sans-serif for controls and data. The visual system will use soft shadows rather than dense borders, 16–24px card radii, 8px spacing increments, and restrained motion under 300ms. Decorative gradients should support hierarchy rather than compete with content.

The skin-analysis page will use calm, clinical-adjacent presentation without looking like a medical portal. Scores will be shown with labels such as “balanced,” “watch,” or “focus area,” not diagnostic severity language. The try-on studio will be more immersive, using a darkened canvas and floating controls to distinguish experimentation from the rest of the workspace.

Accessibility requirements include visible focus rings, semantic headings, sufficient color contrast, keyboard-reachable controls, reduced-motion support, descriptive labels for image upload, and non-color-only status communication. All skin and fashion images must include meaningful alternative text or be marked decorative where appropriate.

---

# Page 6 — Technical Architecture on Manus

The application will use the initialized Manus full-stack template: React 19 on the client, Express-based server runtime, tRPC procedures, Drizzle ORM, MySQL/TiDB-compatible database, Manus OAuth, and managed object storage. This architecture preserves type flow from server contract to UI and keeps credentials server-side.

The client will be organized around `client/src/pages`, shared components, the persistent dashboard shell, and tRPC hooks. The server will be split into focused router modules as the procedure surface grows. The database schema will define users, profiles, wardrobe items, outfit plans, skin analyses, routines, products, try-on sessions, and tone palettes.

The AI boundary will be server-only. The application will call the built-in LLM helper for structured reasoning and vision-capable model requests. A separate adapter interface will allow a future Perfect Corp/YouCam implementation without changing the page components. The client will never receive API secrets and will not call third-party AI providers directly.

The deployment target is Manus Autoscale by default. The core experience is request/response based and does not require a continuously running worker. Long-running third-party analysis tasks will be represented by a stored task record and polled from the page only when the vendor API requires it. Persistent hosting is not necessary for the initial release.

---

# Page 7 — Data Model and Persistence Strategy

The data model will be user-scoped. Every feature record must be associated with the authenticated Manus user. Image bytes will live in managed storage; database rows will store object keys, URLs or references, MIME type, dimensions, and lifecycle metadata. Sensitive image records should support deletion and should not be copied into logs.

| Entity | Important fields | Purpose |
|---|---|---|
| Beauty profile | skin type, concerns, allergies, preferences, consent | Personalization context |
| Wardrobe item | image key, category, color, style, season, tags | Garment inventory |
| Outfit plan | date, occasion, weather, item IDs, rationale | Recommendation history |
| Skin analysis | image key, scores JSON, tone, confidence, createdAt | Longitudinal skin record |
| Routine | AM steps, PM steps, rationale, product IDs | Personalized care plan |
| Product | brand, name, concerns, ingredients, source URL | Discovery catalog |
| Try-on session | person image, garment IDs, output reference, status | Experiment history |
| Tone palette | undertone, season, colors, rationale | Style matching |

JSON columns will be used only for provider responses and flexible recommendation payloads; queryable fields such as user ID, creation time, status, and primary scores will remain explicit. The schema will include timestamps in UTC and use server-side authorization checks for every protected procedure.

Schema-first workflow will be followed: edit `drizzle/schema.ts`, generate migration SQL, review it, apply it through the database execution workflow, and verify the resulting tables. Destructive changes will not be used in the first release.

---

# Page 8 — Wardrobe Manager Implementation

Wardrobe Manager will support drag-and-drop or file-picker uploads, preview thumbnails, upload progress, tagging review, search, category filters, color chips, and an empty state that invites the first garment. The user can accept AI tags or edit them manually. AI tagging will produce a constrained structure: category, subcategory, dominant colors, style descriptors, season, formality, and confidence.

The server will accept the image through managed storage, create a pending wardrobe row, and invoke a vision-capable LLM with a strict JSON schema. The response will be validated before the item becomes ready. If vision analysis fails, the item remains editable with a clear “needs review” state rather than disappearing.

The gallery will support a masonry-like responsive grid on desktop and a two-column card grid on mobile. Each item card will show the image, primary category, color swatches, and a small confidence or review marker. The user can open a detail drawer to edit tags, archive an item, or include it in an outfit request.

The first release will use the existing source archive’s vocabulary and sample patterns but will avoid seeding fake user-generated reviews or testimonials. Any demonstration content will be labeled as sample wardrobe content and will not be represented as user activity.

---

# Page 9 — AI Outfit Recommendations

The Outfits page will combine wardrobe inventory, current weather context, user-selected occasion, style preferences, tone palette, and recent outfit history. The user can request “Today’s look,” choose an occasion such as work, casual, event, or travel, and optionally add a free-text constraint such as “no heels” or “keep it cool.”

The LLM will return a structured plan containing a title, item IDs, styling rationale, confidence, weather notes, alternatives, and a sustainability or repeat-wear note. The server will enforce that referenced item IDs belong to the authenticated user. The UI will display the rationale beside the look so the recommendation feels understandable rather than arbitrary.

Weather will be treated as optional context. If no weather provider is configured, the interface will accept a manual temperature and condition selection. This makes the product usable without forcing an external weather credential into the first release.

The architecture will leave room for a future multi-agent orchestrator: garment vision can classify inventory, a context agent can normalize weather and occasion, a stylist agent can propose looks, and a critic agent can validate color and practicality. The initial implementation can call one structured LLM procedure with these roles expressed in the prompt and later split them behind stable server contracts.

---

# Page 10 — YouCam-Style Virtual Try-On Studio

The Virtual Try-On Studio will present a focused canvas where a user uploads a photo, selects one or more wardrobe pieces, and previews a look. The interface will include garment chips, layer ordering, opacity controls for overlay mode, reset, save session, and download/share affordances when an output image exists.

The try-on service will use an adapter with two modes. **Provider mode** will call a configured YouCam/Perfect Corp apparel endpoint when the user supplies the required credential and product contract. **Fallback mode** will provide a polished overlay experience using the user photo and wardrobe image cutouts, clearly labeled as a preview rather than photorealistic generation. This ensures the web application remains usable during integration and credential setup.

The provider adapter must normalize asynchronous task status into `queued`, `running`, `success`, and `error`. It must not expose provider keys to the browser. It must also avoid logging image URLs or raw payloads containing personal data.

The visual experience should feel distinct from the data-heavy dashboard: dark canvas, warm control surfaces, large preview, and a right-side “look recipe” card explaining the combination. A future extension may add makeup or jewelry try-on, but the first release prioritizes clothing combinations and a strong handoff to tone palette matching.

---

# Page 11 — AI Skin Analysis

Skin Analysis will accept a front-facing, well-lit face image and return a structured wellness report. Required user-facing categories are hydration, texture, tone, pores, and wrinkles. The response may include additional non-diagnostic observations such as redness, oiliness, radiance, or visible blemish signals when supported by the chosen provider.

The built-in vision LLM will be used for the initial Manus implementation with strict JSON output. A provider adapter will be reserved for Perfect Corp’s Skin Analysis API, which documents structured numeric scores, detection masks, task-based processing, and multiple concern categories [1] [2]. The implementation must treat provider scores as analysis signals, not medical diagnoses.

The upload flow will include a consent statement, photo guidance, privacy explanation, preview, cancellation, progress state, and retry action. The result page will show an overall skin wellness summary, five primary score cards, confidence notes, “what this may suggest” language, and a non-medical disclaimer. The user can save the result to history or delete the image and record.

The system prompt will instruct the model not to diagnose diseases, infer protected attributes, make claims about identity, or recommend unsafe treatment. Low-quality images should return a structured retry reason such as poor lighting, face not centered, or insufficient visibility.

---

# Page 12 — Personalized Skincare Routine Builder

My Skin Routine will convert the latest analysis and beauty profile into an editable morning and evening routine. Each step will include a product category, purpose, suggested ingredient families, frequency, and caution notes. The output should be actionable but not prescriptive in a medical sense.

The routine builder will first ask for profile constraints: skin type, concerns, allergies, pregnancy-related restrictions if the user chooses to disclose them, fragrance preference, budget, and routine complexity. Allergy data must be treated as a hard exclusion filter for product recommendations and as a warning when ingredient metadata is incomplete.

The LLM will return a strict routine schema. A server-side validator will remove or flag any product suggestion that conflicts with the profile. The UI will allow the user to reorder steps, mark a step as completed, snooze a step, and regenerate with a narrower instruction such as “simpler routine” or “fragrance-free.”

The page will include clear guidance that users should patch test products and consult a dermatologist or clinician for persistent, painful, rapidly changing, or concerning symptoms. This is consistent with the ethical literature emphasizing reliability, privacy, inclusivity, transparency, accountability, and informed consent in AI dermatology systems [3].

---

# Page 13 — Skin Tone Detection and Color Palette Matching

Skin Tone Studio will analyze tone and undertone from an uploaded image or a saved analysis, then produce a clothing palette. The experience will separate observable color analysis from identity inference. It will use terms such as warm, cool, neutral, or mixed undertone only when the model has adequate confidence, and it will offer a manual correction path.

The palette output will include hero colors, neutrals, accent colors, metals, and colors to experiment with. Each swatch will have a name, hex value, and short styling rationale. The user can apply a palette filter in Wardrobe and ask Outfits to prioritize the palette.

The product must be inclusive. Lighting, camera processing, makeup, and white balance can affect color estimation. The UI will display an uncertainty note and avoid treating tone analysis as a fixed identity category. The model prompt will explicitly prohibit inferring race, ethnicity, health status, or other sensitive attributes.

A palette record will be versioned so that the user can compare or replace a previous result. The tone studio will also support manual undertone selection so the feature remains useful when image quality is inadequate.

---

# Page 14 — Skincare Product Discovery

Product Discovery will display curated product cards matched to the user’s concerns, routine step, ingredient preferences, allergies, and budget. Each card will show product name, category, price band, source link, ingredient highlights, why it may fit, and important exclusions or caveats.

The initial catalog can be a controlled internal dataset of product metadata without fake reviews, ratings, or testimonials. The application will not fabricate social proof. If a product lacks complete ingredient data, the card will say so and will not imply allergy safety.

Ranking will combine concern match, routine step, allergy compatibility, preference match, and confidence in the metadata. The LLM may explain the match but should not invent ingredients or clinical claims. Product facts should come from stored metadata or a verified source rather than generated prose.

The user can save, hide, compare, or mark a product as already owned. Product discovery must remain a recommendation layer rather than an undisclosed advertising surface. If affiliate or sponsored links are later added, the disclosure should be visible in the product card.

---

# Page 15 — Skin Analysis History and Progress Dashboard

The history dashboard will visualize change over time for hydration, texture, tone, pores, and wrinkles. It will show the date of each scan, score direction, image-quality status, and a short summary of what changed. Trends must not be overinterpreted: the page will explain that lighting, camera, expression, and time between scans can affect scores.

Charts will use accessible labels and tabular fallbacks. The user can choose a range such as 30, 90, or 180 days, select one or more metrics, and open the underlying analysis record. A progress narrative will be generated only from stored values and should distinguish observation from recommendation.

The database will store normalized primary scores and the raw provider response separately. The chart layer will read normalized scores. If a record is deleted, the associated chart point must disappear. Image thumbnails may be optional; the user should be able to retain scores while deleting source photos if the product supports that choice.

The dashboard will also include a routine adherence summary only if the user has actively marked routine steps. It will never claim that adherence caused a score change without evidence.

---

# Page 16 — Beauty and Wellness Profile

The profile is the personalization spine of the product. It will store skin type, skin concerns, allergies, ingredient preferences, fragrance preference, budget, routine complexity, style preferences, climate, and optional measurement or sizing information. The user must be able to edit, clear, and export these values.

Profile fields will be grouped into “Skin and wellness,” “Style and wardrobe,” “Shopping preferences,” and “Privacy and data.” Sensitive fields will use explicit descriptions and optionality. The system will ask for consent before a face image is analyzed and will provide a way to delete analysis history.

Profile changes should immediately influence future recommendations but should not silently rewrite old records. Each analysis and routine will store a snapshot of the relevant profile context used at generation time, making results explainable.

The profile page will include an explanation card titled “How ClosetAI uses this.” It will list examples: allergies filter products; undertone influences palette; occasion and weather influence outfits; recent analyses influence routine suggestions. This transparent mapping is a core trust feature.

---

# Page 17 — AI Contracts, Safety, and Provider Adapters

All AI outputs will use typed schemas. Wardrobe tags, outfit plans, skin reports, routines, tone palettes, and product explanations will each have a Zod schema or equivalent server-side validator. Invalid output will produce a recoverable error and will not be written as trusted data.

Model selection will be cost-aware. A fast model is suitable for classification and tagging, while a stronger vision-capable model is appropriate for image analysis and nuanced structured recommendations. The exact live model catalog must be checked in the project environment before hardcoding a model ID. The server will call the built-in helper with credentials already injected by Manus.

The YouCam/Perfect Corp adapter will be optional and isolated behind an interface such as `analyzeSkin`, `analyzeTone`, and `tryOnClothes`. The initial app can run without those credentials by using the built-in vision path and fallback try-on mode. When provider credentials are added, the UI should report which engine produced a result.

Safety controls include no diagnosis, no emergency triage beyond a general recommendation to seek professional care, no sensitive attribute inference, no fabricated product facts, no hidden image retention, no logging of raw face images, and no unverified medical claims. Fairness and representation testing should include varied lighting and skin tones because dermatology AI literature identifies potential performance gaps for skin of color [3].

---

# Page 18 — API, Database, and Storage Implementation Sequence

Implementation will proceed in vertical slices. First, create schema tables and server helpers for profiles and wardrobe items. Second, implement the dashboard and profile context. Third, add wardrobe upload and tagging. Fourth, add outfit generation. Fifth, add analysis and routine flows. Sixth, add tone, product discovery, history, and try-on persistence.

The key protected procedures will include `profile.get`, `profile.update`, `wardrobe.list`, `wardrobe.createUpload`, `wardrobe.updateTags`, `outfits.generate`, `outfits.list`, `skinAnalysis.create`, `skinAnalysis.getLatest`, `skinAnalysis.history`, `routine.generate`, `routine.update`, `tone.analyze`, `products.listMatched`, and `tryOn.createSession`.

Every procedure will verify ownership through the authenticated user context. File upload endpoints will validate MIME type and size, write to managed storage, and persist only metadata. AI calls will use bounded payloads, timeouts, retries where safe, and structured error mapping.

The frontend will use the scaffold’s tRPC binding. No ad hoc Axios or direct browser calls to the built-in AI endpoint will be introduced. Loading states, mutation invalidation, optimistic updates where appropriate, and toasts will be consistent across pages.

---

# Page 19 — Testing, Accessibility, and Launch Validation

Unit tests will cover schema validation, AI output normalization, profile update authorization, wardrobe ownership, score normalization, allergy filtering, palette formatting, and routine exclusions. Tests will use deterministic fixtures that are not presented as customer reviews, ratings, or testimonials.

Integration tests will invoke the server router with authenticated and unauthenticated contexts. They will verify that a user cannot read another user’s wardrobe or analysis. AI calls will be mocked at the service boundary with structured responses, and invalid responses will be tested explicitly.

Browser validation will cover first load, sign-in entry, sidebar navigation, empty states, upload success and error states, responsive layouts, keyboard focus, chart readability, and try-on interactions. Preview screenshots will be captured at desktop and mobile widths. Build, type checking, linting, and Vitest must pass before the final checkpoint.

Launch readiness requires that every requested sidebar section is reachable, every primary button has a meaningful result, all images resolve through managed storage or stable external URLs, no secrets appear in client code, and no placeholder text remains in the main product flow. The product will be published only after the final checkpoint is saved.

---

# Page 20 — Delivery Plan, Risks, and Future Roadmap

The delivery will include the working Manus application, the 20-page plan, the source-informed implementation, test coverage, and a final checkpoint version link. The user will be able to open the application from the Manus Management UI and publish it using the enabled Publish action after the checkpoint is created.

| Risk | Mitigation | Release treatment |
|---|---|---|
| YouCam credential unavailable | Adapter plus built-in vision fallback | Ship integration-ready flow |
| AI output variability | Strict schemas, retries, validation | Block invalid persistence |
| Image privacy concerns | Consent, storage references, delete controls | Document in UI |
| Poor lighting or framing | Upload guidance and retry reasons | Friendly recovery state |
| Skin-tone bias | Uncertainty, manual correction, varied test set | No identity inference |
| Product metadata gaps | Controlled catalog and disclosure | No invented ingredients |
| Long-running provider task | Persist task status and poll as needed | No request-blocking loop |

After launch, the next roadmap items are live camera capture, production Perfect Corp task integration, improved garment segmentation, calendar integration, weather provider integration, product catalog ingestion, routine adherence reminders, clinician-reviewed educational content, and optional mobile packaging. These should be added only after the first release has stable privacy controls, reliable schemas, and observable user value.

The guiding principle is that ClosetAI should become more useful as it learns the user’s preferences without becoming opaque. Every recommendation should show its context, every analysis should communicate uncertainty, and every saved image or profile field should remain under user control.

---

## References

[1]: https://yce.perfectcorp.com/ai-api/products/skin-analysis-api "Perfect Corp. Skin Analysis API"

[2]: https://docs.perfectcorp.com/reference/ai_skin_analysis "Perfect Corp. AI Skin Analysis API Reference"

[3]: https://pubmed.ncbi.nlm.nih.gov/38330217/ "Ethical considerations for artificial intelligence in dermatology: a scoping review"

[4]: https://yce.perfectcorp.com/ai-api "Perfect Corp. Generative AI API for Skincare, Beauty, Apparel, and Jewelry"

[5]: https://docs.perfectcorp.com/develop/introduction "Perfect Corp. YouCam API Developer Documentation"
