import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import SharePage from "@/pages/SharePage";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/wardrobe" component={Home} />
      <Route path="/outfits" component={Home} />
      <Route path="/skin-analysis" component={Home} />
      <Route path="/my-skin-routine" component={Home} />
      <Route path="/skin-tone-studio" component={Home} />
      <Route path="/trends" component={Home} />
      <Route path="/try-on" component={Home} />
      <Route path="/share/:token" component={SharePage} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
