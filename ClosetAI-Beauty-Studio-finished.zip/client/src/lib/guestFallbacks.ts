export type GuestProgressFallback = {
  morningDone: boolean;
  eveningDone: boolean;
  streak: number;
};

type ProgressLike = {
  morningDone?: unknown;
  eveningDone?: unknown;
  streak?: unknown;
} | null | undefined;

export function getGuestProgress(value: ProgressLike, error?: unknown): GuestProgressFallback {
  if (error) return { morningDone: false, eveningDone: false, streak: 0 };
  return {
    morningDone: Boolean(value?.morningDone),
    eveningDone: Boolean(value?.eveningDone),
    streak: typeof value?.streak === "number" ? value.streak : 0,
  };
}

export function getGuestListFallback<T, D>(value: T[] | null | undefined, demo: D[], error?: unknown): Array<T | D> {
  return error || !value?.length ? demo : value;
}
